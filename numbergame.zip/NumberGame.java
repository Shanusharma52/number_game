import java.util.Scanner;
public class NumberGame
{
	public static void main(String[] args) {  
	    Scanner sc=new Scanner(System.in);
	    int chances=8;
	    int finals=0;
	    boolean playAgain=true;
		System.out.println("welcome Buddy!");
		System.out.println("hey buddy you have about"+chances+" chances to win the game");
		while(playAgain){
		    int rand=getrandN(1,100);
		    boolean guess=false;
		    for(int i=0;i<chances;i++){
		     System.out.println("chance"+(i+1)+"      please Enter your guess:");
		     int user=sc.nextInt();
		     if(user==rand){
		         guess=true;
		         finals+=1;
		         System.out.println("you Won the game.");
		         break;
		     }
		     else if(user>rand){
		         System.out.println(" you entered too high");
		     }
		     else{
		         System.out.println(" you entered Too low");
		     }
		    }
		    if(guess==false){
		        System.out.println("sorry buddy. You lost the chances and game.The number is "+rand);
		    }
		    System.out.println("do you want  to play again please enter(y/n)");
		    String pA=sc.next();
		    playAgain=pA.equalsIgnoreCase("y");
		}
		System.out.println("That's it buddy, hope you enjoyed it ");
		System.out.println("Here is your score: "+finals);
	}
		public static int getrandN(int min,int max){
		    return (int)(Math.random()*(max-min+1)+min);
		}
		
}